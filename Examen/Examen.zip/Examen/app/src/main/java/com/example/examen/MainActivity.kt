package com.example.examen
import Fruit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager

class MainActivity : AppCompatActivity() {



    private lateinit var recyclerView: RecyclerView

    private lateinit var fruitAdapter: FruitAdapter



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)



        val fruits = generateFruits()

        fruitAdapter = FruitAdapter(fruits)



        recyclerView = findViewById(R.id.recyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)

        recyclerView.adapter = fruitAdapter

    }



    private fun generateFruits(): List<Fruit> {

        // Simulated data

        val apple = Fruit("Apple", "A sweet red or green fruit.", R.drawable.apple)

        val banana = Fruit("Banana", "A yellow fruit that's easy to peel.", R.drawable.banana)

        val orange = Fruit("Orange", "A round citrus fruit.", R.drawable.orange)



        return listOf(apple, banana, orange)

    }

}
