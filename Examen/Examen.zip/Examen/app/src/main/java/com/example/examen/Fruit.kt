data class Fruit(val name: String, val description: String, val imageResId: Int)
